package com.virtualmusic.in;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class user extends Activity{
	TextView auid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customeraccount);
		
		Button rcp = (Button) findViewById(R.id.rcp);
		Button rdf = (Button) findViewById(R.id.rdf);
		
		Button instr = (Button) findViewById(R.id.instruments);
		Button reviews = (Button) findViewById(R.id.reviews);
		 //button click sound 
		 
		auid=(TextView)findViewById(R.id.aname);
		 //button click sound 
		 String sample1=getIntent().getStringExtra("uid");
		 final String sample=sample1;
			auid.setText(sample1);
			auid.setGravity(Gravity.CENTER);
			auid.setTypeface(null,Typeface.BOLD);
	        //button1 ie Login
		rcp.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent1 = new Intent("com.virtual.music.RCP");
	      		   
	      		   intent1.putExtra("avatarname1", sample);
	      		       startActivity(intent1);
				
				
				
			
				
			}
		});
rdf.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent intent2 = new Intent("com.virtual.music.RDF");
	      		   
	      		   intent2.putExtra("avatarname2", sample);
	      		       startActivity(intent2);
	      		       
			
			
				
			}
		});
//button1 ie Login
		instr.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent3 = new Intent("com.virtual.music.INSTR");
	      		   
	      		   intent3.putExtra("avatarname3", sample);
	      		       startActivity(intent3);
	      		       
	      		       
				
			
				
			}
		});
reviews.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent intent4 = new Intent("com.virtual.music.REVIEWS");
	      		   
	      		   intent4.putExtra("avatarname4", sample);
	      		       startActivity(intent4);
				
			
				
			}
		});
		
	}

	
}
