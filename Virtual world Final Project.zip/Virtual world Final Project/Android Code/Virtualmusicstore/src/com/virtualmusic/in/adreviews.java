package com.virtualmusic.in;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class adreviews extends Activity implements View.OnClickListener{
	private static final String SOAP_ACTION = "http://tempuri.org/replyReviews";

    private static final String METHOD_NAME = "replyReviews";

    private static final String NAMESPACE = "http://tempuri.org/";
    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/ReplyReview.asmx";
    
	EditText mEdit;
    EditText mEdit1;
    EditText mEdit2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adreviews);
		
	}
	public void onClick(View v){}
	public void alertBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		         mEdit   = (EditText)findViewById(R.id.name);
		         mEdit1   = (EditText)findViewById(R.id.receiptname);
		         mEdit2   = (EditText)findViewById(R.id.comments);
		         
		         request.addProperty("AvatarName",mEdit.getText().toString());
  		         request.addProperty("ReceiptName",mEdit1.getText().toString() );
  		       request.addProperty("Comments",mEdit2.getText().toString() );
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		         androidHttpTransport.call(SOAP_ACTION, envelope);
		         
		       Object result = (Object)envelope.getResponse();
		       String temp="Reply to Review added";
		       if(temp.equals(result.toString())){
			         
		    		new AlertDialog.Builder(this)
		    		.setTitle("Review")
		    		.setMessage("Your replay to the review has been added, Thank you")
		    		.setNeutralButton("OK", null)
		    		.show();
    		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Review")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
}
