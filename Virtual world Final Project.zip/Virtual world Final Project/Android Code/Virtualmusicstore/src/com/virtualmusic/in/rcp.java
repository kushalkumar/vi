package com.virtualmusic.in;

import java.util.Vector;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.app.TimePickerDialog;

public class rcp extends Activity{
	private static final String SOAP_ACTION = "http://tempuri.org/concertDates";

    private static final String METHOD_NAME = "concertDates";

    private static final String NAMESPACE = "http://tempuri.org/";
    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/ConcertAvail.asmx";
    
    private static final String SOAP_ACTION1= "http://tempuri.org/addConcert";

    private static final String METHOD_NAME1 = "addConcert";

    private static final String NAMESPACE1 = "http://tempuri.org/";
    private static final String URL1 = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/AddConcertPlace.asmx";
    
	EditText mEdit;
	DatePicker datePicker;
	
	
	static String sample1;
	
	@Override

	protected void onCreate(Bundle savedInstanceState) {
		 String sample=getIntent().getStringExtra("avatarname1");
	sample1=sample;
		 // TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rcp);
		
		 
	}
	public void onClick(View v){}
	public void availBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		      
		     	datePicker = (DatePicker) findViewById(R.id.datePicker1);
	      		 
		         int day = datePicker.getDayOfMonth();
				 int month = datePicker.getMonth() + 1;
				 int year = datePicker.getYear();
				 String date = day+"-"+month+"-"+year;
				 mEdit   = (EditText)findViewById(R.id.enttime);
	      		
				 request.addProperty("date",date);
	      		request.addProperty("time",mEdit.getText().toString());
	      		
	      		
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		         androidHttpTransport.call(SOAP_ACTION, envelope);
		         Object result = (Object)envelope.getResponse();
		         
		         String temp="Concert Place is Available";
			       if(temp.equals(result.toString())){
				         
			    		new AlertDialog.Builder(this)
			    		.setTitle("Concert Place")
			    		.setMessage("Concert is available in the give time and date")
			    		.setNeutralButton("OK", null)
			    		.show();
	    		       }
	    		 
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("Concert Place")
		    		.setMessage("Concert Place is unavailable")
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Concert Place")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
	
	public void confirmBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE1, METHOD_NAME1);
		     
		         
	      		
	      		 
		         datePicker = (DatePicker) findViewById(R.id.datePicker1);
	      		 
		         int day = datePicker.getDayOfMonth();
				 int month = datePicker.getMonth() + 1;
				 int year = datePicker.getYear();
				 String date = day+"-"+month+"-"+year;
				 mEdit   = (EditText)findViewById(R.id.enttime);
	      		
				 request.addProperty("AvatarName",sample1);
				 request.addProperty("Date",date);
	      		request.addProperty("Time",mEdit.getText().toString());
	      		
	      		
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL1);
		         androidHttpTransport.call(SOAP_ACTION1, envelope);
		         
		       Object result = (Object)envelope.getResponse();
		        
		       
		       if(Integer.parseInt( result.toString())!=1){
			         
		    		new AlertDialog.Builder(this)
		    		.setTitle("Concert Place")
		    		.setMessage("Order confirm, Confirmation number:"+ Integer.parseInt( result.toString()) )
		    		.setNeutralButton("OK", null)
		    		.show();
    		       }
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("Concert Place")
		    		.setMessage("not confirmed , problem in confirmation ")
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Concert Place")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
	
	
	
}
