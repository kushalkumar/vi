package com.virtualmusic.in;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;



import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

public class inventory extends Activity{
	private static final String SOAP_ACTION = "http://tempuri.org/inventory";

    private static final String METHOD_NAME = "inventory";

    private static final String NAMESPACE = "http://tempuri.org/";
    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/Inventory.asmx";
    
	EditText mEdit;
    EditText mEdit1;
   
    Spinner spinner1;
    Spinner spinner2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.inventory);
	}
	public void onClick(View v){}
	public void alertBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		         mEdit   = (EditText)findViewById(R.id.quantity);
		         mEdit1   = (EditText)findViewById(R.id.cost);
		     
		         spinner1 = (Spinner)findViewById(R.id.itemname);
	      		   spinner2 = (Spinner)findViewById(R.id.typeofitem);
	      		
	      		 
	      		
	      		request.addProperty("ItemName",spinner1.getSelectedItem().toString());
	      		request.addProperty("TypeofItem",spinner2.getSelectedItem().toString());
	      		
	      		request.addProperty("Quantity",mEdit.getText().toString());
		         request.addProperty("Cost",mEdit1.getText().toString());
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		         androidHttpTransport.call(SOAP_ACTION, envelope);
		         
		       Object result = (Object)envelope.getResponse();
		       String temp="Item added to the inventory";
		       if(temp.equals(result.toString())){
			         
		    		new AlertDialog.Builder(this)
		    		.setTitle("Inventory")
		    		.setMessage("Your Item  has been added to the inventory, Thank you")
		    		.setNeutralButton("OK", null)
		    		.show();
    		       }
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("Inventory")
		    		.setMessage(result.toString())
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Inventory")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
}
