package com.virtualmusic.in;

import java.util.Vector;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class clogin extends Activity {
	 private static final String SOAP_ACTION = "http://tempuri.org/avatarValidation";

	    private static final String METHOD_NAME = "avatarValidation";

	    private static final String NAMESPACE = "http://tempuri.org/";
	    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/Service1.asmx";
	
	    TextView tv;
		
		    EditText cuid;
		    EditText cpassword;
		    Button csubmit;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user);
	}

public void onClick(View v){}
public void loginBtn(View v)
{
		 csubmit = (Button) findViewById(R.id.csubmit);
		
		 tv=(TextView)findViewById(R.id.result);
			 //button click sound 
			 
		        
		        //button1 ie Login
		
					// TODO Auto-generated method stub
					
					
					try {
						// TODO Auto-generated method stub
						 SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		  		         cuid   = (EditText)findViewById(R.id.cid);
		  		         cpassword  = (EditText)findViewById(R.id.cpassword);

		  		         request.addProperty("uname",cuid.getText().toString() );
		  		         request.addProperty("password",cpassword.getText().toString() );

		  		         SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		  		         envelope.dotNet=true;
		  		         envelope.setOutputSoapObject(request);

		  		         HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		  		         androidHttpTransport.call(SOAP_ACTION, envelope);

		  		         SoapObject result = (SoapObject)envelope.getResponse();
		  		       //startActivity(new Intent("com.truzar.planurtravel.SEARCH"));
		  		        	//tv1.setText(result.toString());
		  		       int count = result.getPropertyCount();
		      		     String[] mylist = getStringArrayResponse(count,result, null);
		      		     
		  		        String temp=mylist[0];
		  		        String temp1="Successfully Login";
		  		         
		  		         if(temp1.equals(temp)){
		  		        	Intent intent = new Intent("com.virtual.music.CSUBMIT");
				      		   
				      		   intent.putExtra("uid", mylist[1]);
				      		       startActivity(intent);
		  		       }
		  		       else
		  		         {
		  		        	new AlertDialog.Builder(this)
				    		.setTitle("Authentication")
				    		.setMessage("Invalid Userid or Password")
				    		.setNeutralButton("OK", null)
				    		.show();
		  		        
		  		         }
						
						
						 } catch (Exception e) {
		      		         tv.setText(e.getMessage());
		      		         }
					
				
					
				}
		
	
	
	public String[] getStringArrayResponse(int count,SoapObject node, Vector<String> strings) {
	    boolean isFirstCall = false;
	    if (strings == null) {
	        isFirstCall = true;
	        strings = new Vector<String>();
	    }
	    for (int i = 0; i < count; i++) {
	        Object obj1 = node.getProperty(i);
	        if (obj1 instanceof SoapObject) {
	            // don't recurse empty objects
	            if (((SoapObject)obj1).getPropertyCount() > 0) {
	                // recurse into another node to process its nodes/primitives
	                getStringArrayResponse(count,(SoapObject)obj1, strings);
	            }
	        } else if (obj1 instanceof SoapPrimitive) {
	            strings.add(((SoapPrimitive)obj1).toString());
	        }
	    }
	    // only make this for the original caller
	    if (isFirstCall) {
	        return (String[])strings.toArray(new String[strings.size()]);
	    }
	    return null;
	}


}
