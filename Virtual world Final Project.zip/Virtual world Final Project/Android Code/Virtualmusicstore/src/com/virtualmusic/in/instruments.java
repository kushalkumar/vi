package com.virtualmusic.in;

import java.util.Vector;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

public class instruments extends Activity {
	private static final String SOAP_ACTION = "http://tempuri.org/instruments";

    private static final String METHOD_NAME = "instruments";

    private static final String NAMESPACE = "http://tempuri.org/";
    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/InstrumentsAvail.asmx";
    
    private static final String SOAP_ACTION1= "http://tempuri.org/addInstrument";

    private static final String METHOD_NAME1 = "addInstrument";

    private static final String NAMESPACE1 = "http://tempuri.org/";
    private static final String URL1 = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/InstrumentConfirm.asmx";
    

   
    Spinner spinner1;
    Spinner spinner2;
    static String sample1;
    
  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		String sample=getIntent().getStringExtra("avatarname3");
		sample1=sample;
		
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.instruments);
	}
	
	public void onClick(View v){}
	public void availBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		      
		         spinner1 = (Spinner)findViewById(R.id.instrname);
	      		   spinner2 = (Spinner)findViewById(R.id.typeofinstr);
	      		
	      		 
	      		
	      		request.addProperty("instrname",spinner1.getSelectedItem().toString());
	      		request.addProperty("type",spinner2.getSelectedItem().toString());
	      		
	      		
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		         androidHttpTransport.call(SOAP_ACTION, envelope);
		         
		         SoapObject result = (SoapObject)envelope.getResponse();
	  		       //startActivity(new Intent("com.truzar.planurtravel.SEARCH"));
	  		        	//tv1.setText(result.toString());
	  		       int count = result.getPropertyCount();
	      		     String[] mylist = getStringArrayResponse(count,result, null);
	      		     
	  		        String temp=mylist[0];
	  		        String temp1="Instruments Available";
	  		         
	  		         if(temp1.equals(temp)){
			         
		    		new AlertDialog.Builder(this)
		    		.setTitle("Instruments")
		    		.setMessage("Instruments are available, Availability : "+mylist[1])
		    		.setNeutralButton("OK", null)
		    		.show();
    		       }
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("Instruments")
		    		.setMessage(mylist[0])
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Instruments")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
	
	public void confirmBtn(View v)
	{
		try {

		         SoapObject request = new SoapObject(NAMESPACE1, METHOD_NAME1);
		     
		         spinner1 = (Spinner)findViewById(R.id.instrname);
	      		   spinner2 = (Spinner)findViewById(R.id.typeofinstr);
	      		
	      		 
	      		 request.addProperty("AvatarName",sample1);
	      		request.addProperty("ItemName",spinner1.getSelectedItem().toString());
	      		request.addProperty("TypeofItem",spinner2.getSelectedItem().toString());
	      		
	      		
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL1);
		         androidHttpTransport.call(SOAP_ACTION1, envelope);
		         
		       Object result = (Object)envelope.getResponse();
		        
		       
		       if(Integer.parseInt( result.toString())!=1){
			         
		    		new AlertDialog.Builder(this)
		    		.setTitle("Instrument")
		    		.setMessage("Order confirm, Confirmation number:"+ Integer.parseInt( result.toString()) )
		    		.setNeutralButton("OK", null)
		    		.show();
    		       }
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("instruments")
		    		.setMessage("not confirmed , problem in confirmation ")
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Instruments")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
	public String[] getStringArrayResponse(int count,SoapObject node, Vector<String> strings) {
	    boolean isFirstCall = false;
	    if (strings == null) {
	        isFirstCall = true;
	        strings = new Vector<String>();
	    }
	    for (int i = 0; i < count; i++) {
	        Object obj1 = node.getProperty(i);
	        if (obj1 instanceof SoapObject) {
	            // don't recurse empty objects
	            if (((SoapObject)obj1).getPropertyCount() > 0) {
	                // recurse into another node to process its nodes/primitives
	                getStringArrayResponse(count,(SoapObject)obj1, strings);
	            }
	        } else if (obj1 instanceof SoapPrimitive) {
	            strings.add(((SoapPrimitive)obj1).toString());
	        }
	    }
	    // only make this for the original caller
	    if (isFirstCall) {
	        return (String[])strings.toArray(new String[strings.size()]);
	    }
	    return null;
	}
}
