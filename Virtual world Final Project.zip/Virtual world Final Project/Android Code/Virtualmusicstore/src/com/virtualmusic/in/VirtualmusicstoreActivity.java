package com.virtualmusic.in;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class VirtualmusicstoreActivity extends Activity {

	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button Admin = (Button) findViewById(R.id.admin);
		Button user = (Button) findViewById(R.id.user);
		
		 //button click sound 
		 
	        
	        //button1 ie Login
		Admin.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent("com.virtual.music.LADMIN"));
			
				
			}
		});
user.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent("com.virtual.music.LCUSTOMER"));
			
				
			}
		});

    }
}