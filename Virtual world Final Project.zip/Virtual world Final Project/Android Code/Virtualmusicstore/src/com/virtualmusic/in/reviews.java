package com.virtualmusic.in;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

public class reviews extends Activity {
	private static final String SOAP_ACTION = "http://tempuri.org/reviews";

    private static final String METHOD_NAME = "reviews";

    private static final String NAMESPACE = "http://tempuri.org/";
    private static final String URL = "http://vhost0185.dc1.co.us.compute.ihost.com/Virtualmusicstore1/Reviews.asmx";
    EditText mEdit;
    Spinner spinner1;
    Spinner spinner2;
    RatingBar ratingBar;
    static String sample1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		String sample=getIntent().getStringExtra("avatarname4");
		sample1=sample;
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reviews);
		
	}
	public void onClick(View v){}
	public void submitBtn(View v)
	{
		 
		try {

		         SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
		      
		     	
		         spinner1 = (Spinner)findViewById(R.id.EntItem);
	      		   spinner2 = (Spinner)findViewById(R.id.Entcategory);
	      		 ratingBar = (RatingBar) findViewById(R.id.rating);
	      		 mEdit   = (EditText)findViewById(R.id.comments);
	      		 
	      		request.addProperty("AvatarName",sample1);
	      		request.addProperty("ItemName",spinner1.getSelectedItem().toString());
	      		request.addProperty("Category",spinner2.getSelectedItem().toString());
	      		
	      		request.addProperty("Rating",String.valueOf(ratingBar.getRating()));
		         
	      		request.addProperty("Comments",mEdit.getText().toString());
		         
		        
	      		
	      		
  		        
  		       SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		         envelope.dotNet=true;
		         envelope.setOutputSoapObject(request);

		       HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
		         androidHttpTransport.call(SOAP_ACTION, envelope);
		         Object result = (Object)envelope.getResponse();
		         
		         String temp="Review added";
			       if(temp.equals(result.toString())){
				         
			    		new AlertDialog.Builder(this)
			    		.setTitle("Review")
			    		.setMessage("Review is Added, Thank you for the feedback")
			    		.setNeutralButton("OK", null)
			    		.show();
	    		       }
	    		 
		       else
		       {
		    	   new AlertDialog.Builder(this)
		    		.setTitle("Review")
		    		.setMessage("Review is not added , Problem in adding")
		    		.setNeutralButton("OK", null)
		    		.show();
		       }
    		     } catch (Exception e) {
    		         
    		    		new AlertDialog.Builder(this)
    		    		.setTitle("Review")
    		    		.setMessage(e.getMessage())
    		    		.setNeutralButton("OK", null)
    		    		.show();
    		        
				
    		         }
	
	}
	
}
