package com.virtualmusic.in;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class adminacct extends Activity{
	 TextView auid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminacct);
		 Button ainventory = (Button) findViewById(R.id.aii);
		 Button replyreview = (Button) findViewById(R.id.rtr);
			
		 auid=(TextView)findViewById(R.id.result);
		 //button click sound 
		 String sample1=getIntent().getStringExtra("uid");
			auid.setText(sample1);
	        
	        //button1 ie Login
		ainventory.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent("com.virtual.music.AINVENTORY"));
			
				
			}
		});
replyreview.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent("com.virtual.music.REPLYREVIEW"));
			
				
			}
		});

	}

}
