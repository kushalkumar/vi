﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for DancefloorAvail
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class DancefloorAvail : System.Web.Services.WebService
    {

        [WebMethod]
        public string danceDates(string date, string time)
        {
            string value;
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from Dancing where Date='" + date + "' and Time='" + time + "'", conn);
                
                int count = Convert.ToInt32(da.ExecuteScalar());
                




                if (count == 0)
                {
                    value = "Dancing Floor is Available";
                 
                    return value;
                }
                else
                {
                    value = "Not Available";
                    return value;
                }
                da.Dispose();
             
                conn.Close();


            }
            catch (Exception ex)
            {
                value = "Have some exception in code";

                return value;
            }


        }
    }
}
