﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class Service1 : System.Web.Services.WebService
    {

        [WebMethod]
        public String[] avatarValidation(string uname, string password)
        {
            String[] value = new String[2];
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from Avatarusers where avatarid='" + uname + "' and avatarpassword='" + password + "'", conn);
                SqlCommand da1 = new SqlCommand("Select avatarid from Avatarusers where avatarid='" + uname + "' and avatarpassword='" + password + "'", conn);
                int count = Convert.ToInt32(da.ExecuteScalar());
                String uid = Convert.ToString(da1.ExecuteScalar());




                if (count == 1)
                {
                    value[0] = "Successfully Login";
                    value[1] = uid;
                    return value;
                }
                else
                {
                    value[0] = "Incorrect Uname or password";
                    return value;
                }
                da.Dispose();
                da1.Dispose();
                conn.Close();


            }
            catch (Exception ex)
            {
                value[0] = "Have some exception in code";

                return value;
            }


        }
    }
}