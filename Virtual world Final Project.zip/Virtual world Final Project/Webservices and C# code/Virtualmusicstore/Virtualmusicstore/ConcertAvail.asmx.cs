﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Configuration;
using System.Data.SqlClient;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for ConcertAvail
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class ConcertAvail : System.Web.Services.WebService
    {
        [WebMethod]
        public string concertDates(string date, string time)
        {
            string value;
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from Concert where Date='" + date + "' and Time='" + time + "'", conn);
               
                int count = Convert.ToInt32(da.ExecuteScalar());
               



                if (count == 0)
                {
                    value = "Concert Place is Available";
               
                    return value;
                }
                else
                {
                    value = "Concert Place is not Available";
                    return value;
                }
                da.Dispose();
               
                conn.Close();


            }
            catch (Exception ex)
            {
                value = "Have some exception in code";

                return value;
            }


        }
    }
}
