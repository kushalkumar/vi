﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for GetReviews
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class GetReviews : System.Web.Services.WebService
    {

        [WebMethod]
        public String[,] getReviews()
        {
            String[,] arr1 = new String[100,100];
            int i=0;
            int j=0;
            //Declare Connection by passing the connection string from the web config file
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
            //Open the connection
            conn.Open();
            try
            {
                SqlDataReader myReader = null;
                SqlCommand myCommand = new SqlCommand("select * from Reviews",
                                                         conn);

                myReader = myCommand.ExecuteReader();
                while (myReader.Read())
                {
                    arr1[i,j]= myReader["AvatarName"].ToString();
                    arr1[i,j]= myReader["ItemName"].ToString();
                    arr1[i,j]= myReader["Category"].ToString();
                    arr1[i,j]= myReader["Rating"].ToString();
                    arr1[i, j] =myReader["Comments"].ToString();
                    i++; j++;    
                }
                return arr1;
            }
            catch (Exception e)
            {
                String[,] arr3 = new String[1, 1];
                arr3[0, 0] = "9";
                return arr3;

            }
        }


    }
}
