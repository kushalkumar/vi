﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for Dance_confirmationcode
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class Dance_confirmationcode : System.Web.Services.WebService
    {

      
        [WebMethod]
        public string checkDanceConfirmation(string Confirmcode)
        {
            string result;
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from Dancing where Confirmcode='" + Confirmcode + "' and Activate='" + "1" + "'", conn);
             
                int count = Convert.ToInt32(da.ExecuteScalar());
             




                if (count == 1)
                {
                    result = "Confirmation Code is Active, person can use the Dance Place";
                 
                    return result;
                }
                else
                {
                    result = "Confirmation code is wrong or code is not active";
                    return result;
                }
                da.Dispose();
               
                conn.Close();


            }
            catch (Exception ex)
            {
                result = "Have some exception in code";

                return result;
            }


        }
    }
}
