﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for Inventory
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class Inventory : System.Web.Services.WebService
    {

      
        [WebMethod]
        public string inventory(string ItemName, string TypeofItem, string Quantity, string Cost)
        {
            string result;
            try
            {
                //Declare Connection by passing the connection string from the web config file
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
                //Open the connection
                conn.Open();
             
               
                //Declare the sql command
                SqlCommand cmd = new SqlCommand("Insert into Inventory (ItemName,TypeofItem,Quantity,Cost) values ('" + ItemName + "','" + TypeofItem + "','" + Quantity + "','" + Cost + "')", conn);
                //Execute the Insert query
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                //close the connection
                conn.Close();
                //Display sucess message
                result = "Item added to the inventory";
            }
            catch (Exception ex)
            {
                //Display the error message";

                result = "Error while registration, Please try again : <br/>" + ex.StackTrace;
            }

            return result;
        }
    }
}
