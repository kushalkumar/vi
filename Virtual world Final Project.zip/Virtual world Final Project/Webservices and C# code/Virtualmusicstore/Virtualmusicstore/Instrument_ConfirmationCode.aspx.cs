﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        

        protected void Confirm_Click(object sender, EventArgs e)
        {
           
            Label result=new Label();
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from RequestItem where Confirmcode='" + confirmcode.Text + "' and Activate='" + "1" + "'", conn);
             
                int count = Convert.ToInt32(da.ExecuteScalar());
             




                if (count == 1)
                {

                    result.Text = "<b>Confirmation Code is Active, person can take the instrument :   </b>";
                    this.Controls.Add(result);
                    
                 
                   
                }
                else
                {
                    result.Text = "<b>Confirmation code is wrong or code is not active </b>";
                    this.Controls.Add(result);
                    
           
                }
                da.Dispose();
               
                conn.Close();


            }
            catch (Exception ex)
            {
                

                result.Text = "<b>Have some exception in code </b>";
                this.Controls.Add(result);
            }


        
        }
    }
}