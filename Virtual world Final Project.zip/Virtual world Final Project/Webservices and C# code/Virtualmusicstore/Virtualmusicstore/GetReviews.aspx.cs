﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    public partial class GetReviews1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label[] n = new Label[900];
            int i = 0;
            

            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();
                SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn1.Open();
                SqlDataReader myReader = null;
                SqlCommand myCommand = new SqlCommand("select * from Reviews",
                                                         conn);
                myReader = myCommand.ExecuteReader();
                SqlDataReader myReader1 = null;
                SqlCommand myCommand1 = new SqlCommand("select * from ReplyReview",
                                                         conn1);
                myReader1 = myCommand1.ExecuteReader();
                
                while (myReader.Read())
                {    
                    //AvatarName
                    n[i] = new Label();
                    n[i].Text = "<b>Avtar Name :   </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text=myReader["AvatarName"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Name of the Product :  </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader["ItemName"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Category of the product :  </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader["Category"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                       this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Rating :   </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader["Rating"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Comments :   </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader["Comments"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<hr>";
                    this.Controls.Add(n[i]);
                    i = i + 1;
                }
                while (myReader1.Read())
                {
                    //AvatarName
                    n[i] = new Label();
                    n[i].Text = "<b>Admin Avtar Name :   </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader1["AvatarName"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Receipt Avatar Name :  </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader1["ReceiptAvatarName"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<b>Comments :  </b>";
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = myReader1["Comments"].ToString();
                    this.Controls.Add(n[i]);
                    n[++i] = new Label();
                    n[i].Text = "<br/>";
                    this.Controls.Add(n[i]);

                    n[++i] = new Label();
                    n[i].Text = "<hr>";
                    this.Controls.Add(n[i]);
                    i = i + 1;
                }
            }
            catch
            {
                n[110] = new Label();
                n[110].Text = "Error";
                this.Controls.Add(n[110]);
                
            }
        }
    }
}