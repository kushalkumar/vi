﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for InstrumentsAvail
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class InstrumentsAvail : System.Web.Services.WebService
    {

        [WebMethod]
        public String[] instruments(string instrname, string type)
        {
            String[] value = new String[2];
            try 
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand da = new SqlCommand("Select count(*) from Inventory where ItemName='" + instrname + "' and TypeofItem='" + type + "'", conn);
                SqlCommand da1;
                int count = Convert.ToInt32(da.ExecuteScalar());
              




                if (count == 1)
                {
                     da1 = new SqlCommand("Select Quantity from Inventory where ItemName='" + instrname + "' and TypeofItem='" + type + "'", conn);
                    int count1 = Convert.ToInt32(da1.ExecuteScalar());
                    String Quantity = Convert.ToString(da1.ExecuteScalar());
                    if (count1 == 0)
                    {
                        value[0] = "Not Available";
                        return value;
                    }
                    else
                    {
                        value[0] = "Instruments Available";
                        value[1] = Quantity;
                        return value;
                    }
                }
                else
                {
                    value[0] = "Not Available";
                    return value;
                }
                da.Dispose();
                da1.Dispose();
                conn.Close();


            }
            catch (Exception ex)
            {
                value[0] = "Have some exception in code";

                return value;
            }


        }
    }
}
