﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for InstrumentConfirm
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class InstrumentConfirm : System.Web.Services.WebService
    {

        static Random _r = new Random();
        [WebMethod]
        public int addInstrument(string AvatarName, string ItemName, string TypeofItem)
        {

            int result;

            try
            {
                //Declare Connection by passing the connection string from the web config file
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
                //Open the connection
                conn.Open();

                SqlCommand da = new SqlCommand("Select count(*) from Inventory where ItemName='" + ItemName + "' and TypeofItem='" + TypeofItem + "'", conn);
                
                int count = Convert.ToInt32(da.ExecuteScalar());
                if (count == 1)
                {
                    int p = _r.Next();
                    //Declare the sql command
                    SqlCommand cmd = new SqlCommand("Insert into RequestItem (AvatarName,ItemName,TypeofItem,Confirmcode,Activate) values ('" + AvatarName + "','" + ItemName + "','" + TypeofItem + "','" + p + "','" + "0" + "')", conn);
                    //Execute the Insert query
                    SqlCommand da1 = new SqlCommand("Select Quantity from Inventory where ItemName='" + ItemName + "' and TypeofItem='" + TypeofItem + "'", conn);
                    int count1 = Convert.ToInt32(da1.ExecuteScalar());
                    SqlCommand cmd1 = new SqlCommand("Update Inventory SET Quantity='" + (count1 - 1) + "'where ItemName='" + ItemName + "' and TypeofItem='" + TypeofItem + "'", conn);
                    cmd1.ExecuteNonQuery();
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    //close the connection
                    conn.Close();
                    //Display sucess message
                    return p;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                //Display the error message";

                result = 0;
            }

            return result;
        }
    }
}
