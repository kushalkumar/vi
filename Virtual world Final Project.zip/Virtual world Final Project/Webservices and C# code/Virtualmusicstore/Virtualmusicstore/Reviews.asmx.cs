﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for Reviews
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class Reviews : System.Web.Services.WebService
    {

        [WebMethod]
        public string reviews(string AvatarName, string ItemName, string Category, string Rating, string Comments)
        {
            string result;
            try
            {
                //Declare Connection by passing the connection string from the web config file
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
                //Open the connection
                conn.Open();
                
                //Declare the sql command
                SqlCommand cmd = new SqlCommand("Insert into Reviews (AvatarName,ItemName,Category,Rating,Comments) values ('" + AvatarName + "','" + ItemName + "','" + Category + "','" + Rating + "','" + Comments + "')", conn);
                //Execute the Insert query
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                //close the connection
                conn.Close();
                //Display sucess message
                result = "Review added";
            }
            catch (Exception ex)
            {
                //Display the error message";

                result = "Error while registration, Please try again : <br/>" + ex.StackTrace;
            }

            return result;
        }
    }
}
