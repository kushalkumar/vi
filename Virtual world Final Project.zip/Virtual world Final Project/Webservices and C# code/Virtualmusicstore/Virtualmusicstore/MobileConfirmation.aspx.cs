﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    public partial class MobileConfirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        protected void btAdd_Click(object sender, EventArgs e)
        {
            Label[] n = new Label[900];
            int i = 0;
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn.Open();
                SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn1.Open();
                SqlConnection conn2 = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

                //Open the connection
                conn2.Open();
                SqlDataReader myReader = null;
                SqlDataReader myReader1 = null;
                SqlDataReader myReader2 = null;
                SqlCommand da = new SqlCommand("Select count(*) from Concert where Confirmcode='" + TextBox1.Text + "'", conn);
   
                int count = Convert.ToInt32(da.ExecuteScalar());
                SqlCommand da1 = new SqlCommand("Select count(*) from Dancing where Confirmcode='" + TextBox1.Text + "'", conn);

                int count1 = Convert.ToInt32(da1.ExecuteScalar());
                SqlCommand da2 = new SqlCommand("Select count(*) from RequestItem where Confirmcode='" + TextBox1.Text + "'", conn);

                int count2 = Convert.ToInt32(da2.ExecuteScalar());
                if (count != 0)
                {
                    SqlCommand myCommand = new SqlCommand("select * from Concert where Confirmcode='" + TextBox1.Text + "'", conn);
                    myReader = myCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        //AvatarName
                        n[i] = new Label();
                        n[i].Text = "<b>Avtar Name :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader["AvatarName"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Reserver Date for Concert Room :  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader["Date"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Time of the concert :  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader["Time"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Your Confirm Code :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader["Confirmcode"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "Note : Please pay the amount to Activate your Confirmation code, through Paypal";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<hr>";
                        this.Controls.Add(n[i]);
                        i = i + 1;
                    }
                }
                else if (count1 != 0)
                {
                    SqlCommand myCommand1 = new SqlCommand("select * from Dancing where Confirmcode='" + TextBox1.Text + "'", conn1);
                    myReader1 = myCommand1.ExecuteReader();
                    while (myReader1.Read())
                    {
                        //AvatarName
                        n[i] = new Label();
                        n[i].Text = "<b>Avtar Name :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader1["AvatarName"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Reserver Date for Dancing floor :  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader1["Date"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Time of the Dancing floor :  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader1["Time"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Your Confirm Code :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader1["Confirmcode"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "Note : Please pay the amount to Activate your Confirmation code, through Paypal";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<hr>";
                        this.Controls.Add(n[i]);
                        i = i + 1;
                    }
                }
                else if (count2 != 0)
                {
                    SqlCommand myCommand2 = new SqlCommand("select * from RequestItem where Confirmcode='" + TextBox1.Text + "'", conn2);
                    myReader2 = myCommand2.ExecuteReader();
                    while (myReader2.Read())
                    {
                        //AvatarName
                        n[i] = new Label();
                        n[i].Text = "<b>Avtar Name :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader2["AvatarName"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Reserved Product:  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader2["ItemName"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Type of the product :  </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader2["TypeofItem"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "<b>Your Confirm Code :   </b>";
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = myReader2["Confirmcode"].ToString();
                        this.Controls.Add(n[i]);
                        n[++i] = new Label();
                        n[i].Text = "<br/>";
                        this.Controls.Add(n[i]);

                        n[++i] = new Label();
                        n[i].Text = "Note : Please pay the amount to Activate your Confirmation code, through Paypal";
                        this.Controls.Add(n[i]);


                       

                        n[++i] = new Label();
                        n[i].Text = "<hr>";
                        this.Controls.Add(n[i]);
                        i = i + 1;
                    }
                }
                else
                {
                  
                }



               
                
               
               
               
                conn.Close();
            }
            catch
            {
                  n[110] = new Label();
                n[110].Text = "Error";
                this.Controls.Add(n[110]);
                
            }
        }
    }
}