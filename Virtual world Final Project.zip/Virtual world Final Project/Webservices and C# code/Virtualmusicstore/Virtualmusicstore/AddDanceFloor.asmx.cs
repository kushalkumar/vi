﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for AddDanceFloor
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class AddDanceFloor : System.Web.Services.WebService
    {

        static Random _r = new Random();
        [WebMethod]
        public int addDance(string AvatarName, string Date, string Time)
        {

            int result;

            try
            {
                //Declare Connection by passing the connection string from the web config file
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
                //Open the connection
                conn.Open();

                SqlCommand da = new SqlCommand("Select count(*) from Dancing where Date='" + Date + "' and Time='" + Time + "'", conn);
                
                int count = Convert.ToInt32(da.ExecuteScalar());


                if (count == 0)
                {

                    int p = _r.Next();
                    //Declare the sql command
                    SqlCommand cmd = new SqlCommand("Insert into Dancing (AvatarName,Date,Time,Confirmcode,Activate) values ('" + AvatarName + "','" + Date + "','" + Time + "','" + p + "','" + "0" + "')", conn);
                    //Execute the Insert query
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    //close the connection
                    conn.Close();
                    //Display sucess message
                    return p;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                //Display the error message";

                result = 0;
            }

            return result;
        }
    }
}
