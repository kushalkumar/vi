﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;

namespace Virtualmusicstore
{
    /// <summary>
    /// Summary description for ReplyReview
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    public class ReplyReview : System.Web.Services.WebService
    {

        [WebMethod]
        public string replyReviews(string AvatarName, string ReceiptName, string Comments)
        {
            string result;
            try
            {
                //Declare Connection by passing the connection string from the web config file
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
                //Open the connection
                conn.Open();

                //Declare the sql command
                SqlCommand cmd = new SqlCommand("Insert into ReplyReview (AvatarName,ReceiptAvatarName,Comments) values ('" + AvatarName + "','" + ReceiptName + "','" + Comments + "')", conn);
                //Execute the Insert query
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                //close the connection
                conn.Close();
                //Display sucess message
                result = "Reply to Review added";
            }
            catch (Exception ex)
            {
                //Display the error message";

                result = "Error while registration, Please try again : <br/>" + ex.StackTrace;
            }

            return result;
        }
    }
}
